<!-- Machine-extracted from the source DOCX. The DOCX remains the authoritative source document. -->

Coordination Execution Engine (CEE)

Volume I

Coordination Instruction Set Architecture (CISA)

Document Number: CEE-CISA-001

Version: Draft 0.1

Status: Working Draft

1. Introduction

1.1 Purpose

The Coordination Instruction Set Architecture (CISA) defines the abstract execution model of the Coordination Execution Engine (CEE).

Its purpose is to establish a deterministic computational framework through which independent actors coordinate changes to shared institutional state.

CISA specifies the instructions, runtime primitives, execution semantics and conformance requirements that every compliant implementation of the Coordination Execution Engine shall support.

This specification intentionally excludes application logic, user interface design, networking protocols, storage engines and deployment architecture.

Those concerns belong to implementation-specific systems built upon CISA.

1.2 Design Objectives

A compliant implementation of CISA shall satisfy the following objectives.

Determinism

Identical inputs shall always produce identical state transitions.

Atomicity

State transitions shall either complete entirely or not execute at all.

Authority

No transition shall occur without successful authority verification.

Auditability

Every executed transition shall produce an immutable audit record.

Interoperability

Applications shall interact with the runtime exclusively through defined instructions.

Implementation Independence

The specification shall remain independent of programming language, operating system, hardware architecture and storage technology.

1.3 Conformance

An implementation claiming compliance with this specification shall implement every mandatory instruction defined herein.

Optional extensions may be introduced provided they do not alter the semantics of mandatory instructions.

2. Architectural Model

The Coordination Execution Engine operates upon seven runtime primitives.

No compliant implementation shall introduce additional primitive execution types.

3. Execution Cycle

Every event submitted to the runtime shall execute according to the following sequence.

Receive Event

↓

Authenticate Actor

↓

Verify Signature

↓

Verify Authority

↓

Evaluate Rules

↓

Determine Transition

↓

Execute Transition

↓

Persist History

↓

Publish Updated State

No compliant implementation shall alter this execution order.

4. Runtime Primitives

4.1 Process

Definition

A Process is the fundamental unit of coordinated execution.

Every coordinated activity shall be represented by exactly one Process.

Required Properties

Every Process shall contain:

Process Identifier

Current State

Participant Registry

Authority Registry

Rule Registry

Transition History

Invariants

A Process shall always possess exactly one Current State.

A Process Identifier shall never change after creation.

A Process History shall be append-only.

4.2 State

Definition

A State represents the current authoritative condition of a Process.

Properties

States are immutable definitions.

Processes move between States.

States themselves never change.

Constraints

Only one Current State may exist at any instant.

Transitions between States shall occur only through runtime instructions.

Direct modification of Current State is prohibited.

4.3 Event

Definition

An Event represents an immutable statement that an observable fact has occurred.

Events request evaluation.

Events never directly modify State.

Required Fields

Event Identifier

Actor Identifier

Timestamp

Event Type

Payload

Digital Signature

Invariants

Events shall be immutable after submission.

Events shall never be deleted.

Rejected Events shall remain part of the audit history.

4.4 Transition

Definition

A Transition defines a legal movement from one State to another.

Properties

Every Transition shall specify:

Source State

Destination State

Trigger Event

Required Authorities

Required Rules

Constraints

Implicit Transitions are prohibited.

Undefined Transitions shall be rejected.

4.5 Rule

Definition

A Rule expresses a deterministic predicate evaluated before Transition execution.

Requirements

Rules shall:

Produce a Boolean result.

Be deterministic.

Be free of side effects.

Depend solely upon declared inputs.

Rule evaluation shall never modify Process State.

4.6 Authority

Definition

Authority specifies which Actors may authorize specific Events or Transitions.

Authority shall be represented as declarative metadata.

Authority shall never be embedded within application code.

4.7 Actor

Definition

An Actor is an entity capable of producing Events.

Actor categories include, but are not limited to:

Human

Organization

Software System

Device

Sensor

Artificial Intelligence Agent

Vehicle

Future categories may be introduced without altering runtime semantics.

5. Instruction Categories

Every instruction defined by CISA shall belong to exactly one category.

6. Instruction Definition Format

Every instruction in this specification shall be described using the following template.

Instruction Name

Mnemonic

Category

Purpose

Inputs

Outputs

Preconditions

Execution Semantics

Postconditions

Failure Conditions

Audit Requirements

Determinism Requirements

Security Considerations

This structure is mandatory for every instruction described in subsequent chapters.

Section 7

Process Management Instructions

The Process Management instruction set defines the creation, lifecycle management and termination of coordinated processes.

Every Process SHALL exist within the Coordination Runtime and SHALL be uniquely identifiable throughout its lifetime.

A Process SHALL transition only through legal State transitions defined by this specification.

Instruction 001

CREATE_PROCESS

Mnemonic

CREATE_PROCESS

Category

Process Management

Purpose

Creates a new Process instance within the Coordination Runtime.

A Process represents a single coordinated activity whose state SHALL be managed by the runtime.

Successful execution of this instruction allocates runtime resources, initializes the Process, establishes its initial State and creates an immutable audit record.

Syntax

CREATE_PROCESS

TYPE        <ProcessType>

ID          <ProcessIdentifier>

INITIAL     <StateIdentifier>

Operands

Preconditions

Before execution, the runtime SHALL verify that:

• the supplied Process Identifier does not already exist.

• the referenced Process Type has been registered.

• the Initial State has been declared.

• the caller possesses authority to create the specified Process Type.

Failure of any precondition SHALL terminate execution.

Execution Semantics

Upon successful execution, the runtime SHALL perform the following operations in order.

Allocate a new Process object.

Assign the supplied Process Identifier.

Assign the declared Process Type.

Set the Current State to the specified Initial State.

Initialize an empty Transition History.

Initialize an empty Participant Registry.

Initialize an empty Event Queue.

Initialize the Authority Registry.

Record the creation timestamp.

Generate an immutable audit entry.

Execution SHALL be atomic.

If any operation fails, the runtime SHALL discard the partially created Process.

Outputs

Successful execution SHALL return:

Process Identifier

Current State

Creation Timestamp

Runtime Status = CREATED

Postconditions

After successful execution:

the Process SHALL exist.

the Process SHALL possess exactly one Current State.

the Transition History SHALL contain exactly one entry representing Process creation.

the Process SHALL be eligible to receive Events.

Failure Conditions

The runtime SHALL reject execution if:

• the Process Identifier already exists.

• the Initial State is undefined.

• the Process Type is unknown.

• the Actor lacks authority.

• runtime resource allocation fails.

Determinism Requirements

Given identical operands and identical runtime configuration, every compliant implementation SHALL produce identical Process state.

No implementation-defined behaviour is permitted.

Audit Requirements

The runtime SHALL append an immutable audit record containing:

Instruction

Timestamp

Actor Identifier

Process Identifier

Process Type

Initial State

Execution Result

Audit records SHALL NOT be modified after creation.

Security Considerations

The runtime SHALL authenticate the requesting Actor before execution.

The runtime SHALL verify authorization prior to resource allocation.

Process creation requests SHALL be digitally signed.

Unsigned requests SHALL be rejected.

Replay attacks SHALL be detected through nonce or equivalent replay-protection mechanisms.

Complexity

Expected Time Complexity

O(1)

Expected Memory Allocation

One Process object.

One History object.

One Authority Registry.

One Event Queue.

Example

CREATE_PROCESS

TYPE        PassportApplication

ID          PAS-00012345

INITIAL     SUBMITTED

Expected Result

STATUS: CREATED

PROCESS: PAS-00012345

CURRENT_STATE: SUBMITTED

TIMESTAMP:

2026-07-20T09:14:22Z

Instruction 002

REGISTER_ACTOR

Mnemonic

REGISTER_ACTOR

Category

Actor Management

Purpose

Registers an Actor with the Coordination Runtime.

An Actor represents an entity capable of submitting Events to one or more Processes.

An Actor SHALL possess a globally unique identifier and SHALL be uniquely distinguishable from every other Actor within the runtime.

Registration SHALL NOT grant authority.

Authority SHALL be assigned explicitly through separate instructions.

Section 7.2

Instruction 002

REGISTER_ACTOR

Mnemonic

REGISTER_ACTOR

Category

Actor Management

Purpose

Registers an Actor within the Coordination Runtime.

An Actor represents any entity capable of emitting Events.

Actor registration establishes identity only.

It SHALL NOT grant authority, permissions or participation in any Process.

Syntax

REGISTER_ACTOR

ID          <ActorIdentifier>

TYPE        <ActorType>

NAME        <DisplayName>

Operands

Supported Actor Types

Every compliant implementation SHALL support at least:

HUMAN

ORGANIZATION

SERVICE

DEVICE

SENSOR

AI_AGENT

VEHICLE

SYSTEM

Future Actor Types MAY be introduced without modifying runtime semantics.

Preconditions

The runtime SHALL verify:

• Actor Identifier is unique.

• Actor Type is valid.

• Request signature is valid.

Execution Semantics

The runtime SHALL:

Create Actor object.

Assign Actor Identifier.

Assign Actor Type.

Record registration timestamp.

Generate immutable audit record.

Outputs

Actor Identifier

Actor Type

Registration Timestamp

Status = REGISTERED

Postconditions

Registered Actors SHALL become eligible to:

Receive Authority.

Join Processes.

Submit Events.

Registered Actors SHALL NOT automatically receive any privileges.

Failure Conditions

Registration SHALL fail if:

Actor already exists.

Identifier invalid.

Signature invalid.

Storage unavailable.

Security Considerations

Anonymous Actors SHALL NOT exist.

Every Actor SHALL possess a cryptographically verifiable identity.

Instruction 003

ASSIGN_AUTHORITY

Mnemonic

ASSIGN_AUTHORITY

Category

Authority Management

Purpose

Associates an Actor with one or more Authorities.

Authority defines what an Actor may authorize.

Authority SHALL NOT define Process logic.

Authority SHALL remain external to application code.

Syntax

ASSIGN_AUTHORITY

ACTOR      ACT-001

AUTHORITY  PassportApprover

Operands

Preconditions

Runtime SHALL verify:

Actor exists.

Authority exists.

Caller possesses delegation authority.

Execution

Runtime SHALL:

Associate Authority.

Record timestamp.

Generate immutable audit record.

Postconditions

Actor SHALL become eligible to authorize Events requiring that Authority.

Failure Conditions

Unknown Actor.

Unknown Authority.

Delegation denied.

Duplicate assignment.

Instruction 004

CREATE_EVENT

Purpose

Creates an immutable Event object.

Creation SHALL NOT modify runtime state.

Created Events MAY exist outside the Runtime.

This immediately enables:

Offline devices.

Edge nodes.

Mobile phones.

Sensors.

Disconnected districts.

Syntax

CREATE_EVENT

TYPE InspectionPassed

SOURCE ACT-009

PROCESS PAS-000123

PAYLOAD { ... }

Output

Event Identifier

Signature Required

Status = CREATED

Postconditions

The Event SHALL remain mutable only until signed.

Unsigned Events SHALL NOT be accepted by the Runtime.

Instruction 005

SIGN_EVENT

Purpose

Produces a cryptographically verifiable Event.

Signing permanently seals Event contents.

Any modification SHALL invalidate the signature.

Syntax

SIGN_EVENT

EVENT EVT-001

KEY ACTOR_PRIVATE_KEY

Outputs

Event Signature

Hash

Status = SIGNED

Postconditions

Signed Events SHALL become immutable.

Failure Conditions

Missing key.

Corrupted Event.

Expired credentials.

Instruction 006

SUBMIT_EVENT

Mnemonic

SUBMIT_EVENT

Category

Event Management

Purpose

Submits a previously signed Event to the Coordination Runtime for evaluation.

Submission SHALL NOT modify Process State.

Submission SHALL enqueue the Event for deterministic execution.

A submitted Event SHALL become part of the Runtime Execution Pipeline.

Syntax

SUBMIT_EVENT

EVENT      EVT-00004561

Operands

Preconditions

Before accepting an Event, the Runtime SHALL verify:

• the Event exists.

• the Event has been digitally signed.

• the Event has not expired (if expiration policy exists).

• the Event has not previously been submitted.

• the Event has not been revoked.

Failure of any precondition SHALL reject submission.

Execution Semantics

Upon successful execution, the Runtime SHALL:

Receive the Event.

Validate Event structure.

Place the Event into the Runtime Execution Queue.

Assign an Execution Sequence Number.

Record submission timestamp.

Generate an immutable audit record.

Submission SHALL NOT execute the Event.

Execution SHALL occur only after verification.

Outputs

Event Identifier

Execution Sequence

Submission Timestamp

Status = QUEUED

Postconditions

The Event SHALL exist in exactly one of the following states:

QUEUED

EXECUTING

COMPLETED

REJECTED

Failure Conditions

Submission SHALL fail if:

• Event already submitted.

• Event unsigned.

• Event malformed.

• Runtime unavailable.

• Queue capacity exceeded.

Audit Requirements

The Runtime SHALL record:

Instruction

Event Identifier

Submission Time

Queue Position

Submitting Actor

Execution Status

Security Considerations

The Runtime SHALL reject duplicate Event submissions.

Replay protection SHALL be mandatory.

Queue ordering SHALL be deterministic.

Instruction 007

VERIFY_SIGNATURE

Mnemonic

VERIFY_SIGNATURE

Category

Security

Purpose

Verifies the authenticity and integrity of a submitted Event.

Successful verification SHALL confirm:

• the Event originated from the claimed Actor,

• the Event contents have not been modified,

• the signature was produced using a trusted credential.

Signature verification SHALL occur before any authority or rule evaluation.

Syntax

VERIFY_SIGNATURE

EVENT EVT-00004561

Preconditions

The Event SHALL:

• exist,

• be submitted,

• contain a digital signature,

• reference a registered Actor.

Execution Semantics

The Runtime SHALL:

Retrieve the Event.

Retrieve the Actor's public verification credential.

Compute the Event digest.

Verify the digital signature.

Compare the computed digest against the signed digest.

Produce a Boolean verification result.

Signature verification SHALL NOT modify Runtime State.

Outputs

TRUE

or

FALSE

Failure Conditions

Verification SHALL fail if:

• signature invalid,

• signature missing,

• signing credential revoked,

• Event altered,

• digest mismatch.

Security Considerations

Implementations SHOULD support modern public-key signature algorithms.

The specification intentionally does not mandate a specific cryptographic algorithm, allowing implementations to evolve as cryptographic standards advance.

Instruction 008

VERIFY_AUTHORITY

Mnemonic

VERIFY_AUTHORITY

Category

Authority Management

Purpose

Determines whether the Actor associated with an Event possesses the Authority required to request the intended Transition.

Authority verification SHALL evaluate authorization independently of business rules.

Possessing Authority SHALL NOT guarantee that the Transition will execute.

Syntax

VERIFY_AUTHORITY

EVENT EVT-00004561

Preconditions

The Runtime SHALL verify:

• Actor exists.

• Authority exists.

• Transition exists.

• Authority assignment is active.

Execution Semantics

The Runtime SHALL:

Identify the requested Transition.

Retrieve the required Authority.

Retrieve the Actor's assigned Authorities.

Compare required and assigned Authorities.

Return a Boolean authorization result.

Outputs

AUTHORIZED

or

DENIED

Failure Conditions

Authority verification SHALL fail if:

• Actor unknown.

• Authority unknown.

• Authority revoked.

• Transition undefined.

• Authority expired.

Security Considerations

Authority evaluation SHALL be deterministic.

Authority SHALL be data-driven.

No implementation SHALL embed authorization logic within executable application code.

Section 7.9

Execution Context

Definition

An Execution Context is an immutable runtime object constructed immediately after successful Event verification.

The Execution Context SHALL contain every input required to evaluate a proposed State Transition.

Once created, an Execution Context SHALL NOT be modified.

Every subsequent instruction in the execution pipeline SHALL operate exclusively upon the Execution Context.

Purpose

The Execution Context provides a deterministic execution environment.

By assembling all required execution inputs before Rule evaluation begins, the Runtime ensures that every compliant implementation evaluates identical information.

This guarantees deterministic execution across independent Runtime implementations.

Required Components

Every Execution Context SHALL contain:

No implementation SHALL omit any mandatory component.

Instruction 009

EVALUATE_RULES

Mnemonic

EVALUATE_RULES

Category

Rule Evaluation

Purpose

Evaluates every Rule governing the proposed Transition.

The Runtime SHALL evaluate all applicable Rules before any State Transition is executed.

Rule evaluation SHALL NOT modify Runtime State.

Syntax

EVALUATE_RULES

CONTEXT    EC-00000412

Operands

Preconditions

The Runtime SHALL verify that:

• the Execution Context exists.

• the Event has been authenticated.

• the Event signature is valid.

• the Actor possesses required Authority.

• the proposed Transition exists.

Execution Semantics

The Runtime SHALL:

Load the Execution Context.

Retrieve every Rule associated with the proposed Transition.

Evaluate each Rule independently.

Aggregate Rule results.

Produce a single deterministic decision.

Rule evaluation order SHALL be deterministic.

Parallel evaluation MAY be used only if identical results are guaranteed.

Rule Results

Every Rule SHALL produce exactly one of the following outcomes:

PASS

FAIL

No intermediate result SHALL exist.

Runtime Decision

After evaluating every Rule, the Runtime SHALL produce one of the following execution decisions:

ALLOW

DENY

ALLOW indicates that Transition execution MAY proceed.

DENY indicates that Transition execution SHALL terminate.

Outputs

Execution Decision

ALLOW

or

DENY

Failure Conditions

Evaluation SHALL fail if:

• Execution Context missing.

• Rule undefined.

• Rule execution timeout.

• Non-deterministic Rule detected.

• Runtime inconsistency detected.

Determinism Requirements

Rule evaluation SHALL be referentially transparent.

A Rule SHALL always produce the same result for identical inputs.

Rules SHALL NOT:

• modify Process State,

• modify external systems,

• perform network operations,

• depend upon non-deterministic system clocks,

• generate random values.

Audit Requirements

The Runtime SHALL record:

Rule Identifier

Evaluation Result

Evaluation Timestamp

Execution Context Identifier

Decision

Security Considerations

Rule definitions SHALL be immutable during execution.

Rule modifications SHALL require administrative authorization.

A Rule SHALL never execute with elevated privileges.

Instruction 010

EXECUTE_TRANSITION

Mnemonic

EXECUTE_TRANSITION

Category

State Management

Purpose

Performs an atomic State Transition following successful Rule evaluation.

This instruction represents the only mechanism by which a Process may change State.

No other instruction SHALL modify the Current State of a Process.

Syntax

EXECUTE_TRANSITION

CONTEXT    EC-00000412

Preconditions

Before execution, the Runtime SHALL verify:

• Rule evaluation returned ALLOW.

• Current State matches the Execution Context.

• Transition remains valid.

• Process has not changed since Context creation.

Execution Semantics

The Runtime SHALL execute the following operations atomically.

Verify Current State.

Replace Current State with Destination State.

Increment Process Version.

Mark Event as Consumed.

Commit Transition.

Publish Transition Outcome.

If any operation fails, the Runtime SHALL roll back the entire Transition.

Partial execution SHALL NOT occur.

Outputs

Transition Status

SUCCESS

or

FAILED

Postconditions

Following successful execution:

• the Process SHALL occupy the Destination State.

• the previous State SHALL remain in Transition History.

• the triggering Event SHALL NOT be executed again.

• a new Process Version SHALL exist.

Failure Conditions

Execution SHALL fail if:

• Process State changed during evaluation.

• Event previously consumed.

• Transition invalid.

• Commit failed.

• Atomicity could not be guaranteed.

Determinism Requirements

State Transition SHALL be deterministic.

Every compliant Runtime SHALL produce identical Destination State given identical Execution Context.

Audit Requirements

The Runtime SHALL permanently record:

Source State

Destination State

Transition Identifier

Execution Timestamp

Actor Identifier

Authority

Process Version

Event Identifier

Security Considerations

A completed Transition SHALL NOT be reversed by modifying history.

Corrections SHALL occur only through subsequent valid Transitions.

Section 7.11

Instruction 011

RECORD_HISTORY

Mnemonic

RECORD_HISTORY

Category

Audit Management

Purpose

Creates an immutable historical record following successful execution of a State Transition.

The History Record SHALL constitute the permanent evidentiary record of the Transition.

History SHALL be append-only.

No compliant implementation SHALL modify or delete an existing History Record.

Syntax

RECORD_HISTORY

CONTEXT EC-00000412

Preconditions

The Runtime SHALL verify:

• EXECUTE_TRANSITION completed successfully.

• the Transition has been committed.

• the Event has been marked as consumed.

Execution Semantics

The Runtime SHALL:

Create a new History Record.

Assign a globally unique History Identifier.

Associate the History Record with the Process.

Capture the complete Transition metadata.

Append the History Record to the Process History.

Seal the History Record against modification.

History recording SHALL execute atomically.

Required History Fields

Every History Record SHALL contain:

Outputs

History Identifier

Status = RECORDED

Postconditions

Following successful execution:

• the Process History SHALL contain one additional entry.

• the History Record SHALL become immutable.

• the record SHALL be queryable.

Failure Conditions

Execution SHALL fail if:

• Transition not committed.

• duplicate History Identifier detected.

• persistent storage unavailable.

Determinism Requirements

History generation SHALL be deterministic.

Every compliant Runtime SHALL generate identical logical History content for identical Execution Contexts.

Security Considerations

History Records SHALL be tamper-evident.

Any modification attempt SHALL be detectable.

Instruction 012

PUBLISH_STATE

Mnemonic

PUBLISH_STATE

Category

State Distribution

Purpose

Publishes the newly committed authoritative State to interested participants.

State publication SHALL occur only after successful Transition commitment and History recording.

Publication SHALL NOT modify the authoritative State.

Syntax

PUBLISH_STATE

PROCESS PAS-00012345

Preconditions

The Runtime SHALL verify:

• the Transition committed successfully.

• the History Record exists.

Execution Semantics

The Runtime SHALL:

Retrieve the Current State.

Construct a State Publication Message.

Notify subscribed participants.

Mark publication complete.

Publication failures SHALL NOT invalidate the committed Transition.

Publication Contents

Every publication SHALL include:

Outputs

Publication Status

PUBLISHED

or

PARTIALLY_PUBLISHED

or

FAILED

Failure Conditions

Publication MAY fail if:

• communication unavailable.

• subscriber unavailable.

• transport failure.

Publication failure SHALL NOT roll back the committed State.

Security Considerations

Published State SHALL represent committed reality only.

Uncommitted State SHALL never be published.

CISA Axiom 2

Separation of Truth and Notification

The authoritative State of a Process SHALL exist independently of whether publication succeeds.

Notification is not coordination.

Publication informs participants of reality.

Publication does not create reality.

Section 8

Runtime Invariants

Every architecture has invariants—properties that are always true if the system is operating correctly.

These are more important than individual instructions because they define the identity of the runtime.

Invariant 1

A Process SHALL occupy exactly one Current State.

Invariant 2

A State SHALL change only through successful execution of EXECUTE_TRANSITION.

Invariant 3

Every committed Transition SHALL produce exactly one History Record.

Invariant 4

Every consumed Event SHALL be executed at most once.

Duplicate execution is prohibited.

Invariant 5

Every History Record SHALL be immutable.

Corrections SHALL occur only through subsequent Transitions.

Invariant 6

Every published State SHALL correspond to a committed Transition.

Invariant 7

Every compliant Runtime SHALL produce identical authoritative State given identical instruction sequences.

Invariant 8

Application data SHALL remain external to the Coordination Runtime.

The Runtime SHALL coordinate institutional State.

It SHALL NOT become a general-purpose database.

Invariant 9

Rules SHALL be pure functions.

They SHALL produce outputs solely from their declared inputs.

They SHALL NOT produce side effects.

Invariant 10

Every execution SHALL be reproducible through deterministic replay of the Event History.


[TABLE 1]


Primitive | Description

Process | A coordinated activity under execution.

State | The authoritative condition of a Process.

Event | An immutable observation submitted by an Actor.

Transition | A legal movement between States.

Rule | A deterministic condition governing Transitions.

Authority | A declaration of authorization to perform specific actions.

Actor | An entity capable of submitting Events.


[TABLE 2]


Category | Purpose

Process | Create and manage Processes.

Event | Submit and verify Events.

Authority | Register and validate authorization.

State | Query and transition State.

Rule | Register and evaluate Rules.

Synchronization | Coordinate distributed runtimes.

Query | Retrieve runtime information.


[TABLE 3]


Operand | Type | Required | Description

TYPE | String | SHALL | Logical classification of the Process.

ID | UUID or String | SHALL | Globally unique Process Identifier.

INITIAL | State Identifier | SHALL | Initial State of the Process.


[TABLE 4]


Operand | Type | Required | Description

ID | UUIDv7 | SHALL | Globally unique Actor identifier.

TYPE | Enumeration | SHALL | Actor classification.

NAME | UTF-8 String | SHOULD | Human-readable name.


[TABLE 5]


Operand | Description

Actor Identifier | Existing Actor

Authority Identifier | Existing Authority


[TABLE 6]


Operand | Type | Required | Description

EVENT | Event Identifier | SHALL | Identifier of a signed Event.


[TABLE 7]


Component | Description

Event | The submitted Event.

Process | The target Process.

Current State | The authoritative State at execution time.

Proposed Transition | The Transition requested by the Event.

Actor | The originating Actor.

Authorities | Authorities assigned to the Actor.

Rules | Rules governing the proposed Transition.

Timestamp | Runtime execution timestamp.

Execution Sequence | Deterministic ordering identifier.


[TABLE 8]


Operand | Type | Required | Description

CONTEXT | Execution Context | SHALL | Immutable execution context.


[TABLE 9]


Field | Description

History Identifier | Unique record identifier

Process Identifier | Associated Process

Event Identifier | Triggering Event

Transition Identifier | Executed Transition

Source State | Previous State

Destination State | New State

Actor Identifier | Event originator

Authority | Verified Authority

Execution Timestamp | Commit time

Process Version | Version after commit


[TABLE 10]


Field | Description

Process Identifier | Target Process

Current State | Authoritative State

Process Version | Current Version

Transition Identifier | Last committed Transition

Publication Timestamp | Time of publication
