<!-- Machine-extracted from the source DOCX. The DOCX remains the authoritative source document. -->

INSTITUTIONAL VIRTUAL MACHINE (IVM)
Runtime Architecture Specification
Version 1.0 Draft

Coordination Architecture Specification
Volume III

Author
Joel Kagoro

Publication Information

Runtime Architecture Specification
Version 1.0 Draft

Reference Specifications:
CRS
CISA
CEE (Future)

Document Control

Document Identifier: IVM-1.0
Status: Draft
Author: Joel Kagoro

Preface

This document specifies the Institutional Virtual Machine (IVM), the normative execution architecture responsible for implementing the Coordination Instruction Set Architecture (CISA).

Table of Contents

Insert automatic TOC in Microsoft Word.

Chapter 1 - Introduction

The Institutional Virtual Machine defines how compliant execution environments realize the semantics defined by CISA.
