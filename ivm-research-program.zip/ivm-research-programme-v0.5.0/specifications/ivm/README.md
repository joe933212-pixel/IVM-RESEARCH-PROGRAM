# Institutional Virtual Machine Specification

The library currently contains the IVM 1.0 Front Matter document as the verified IVM specification artefact available for this repository build.

The complete IVM specification should be added only when the full source document is available in the research archive. The front matter identifies the document as `IVM-1.0`, Volume III, authored by Joel Kagoro, and states that it specifies the normative execution architecture responsible for implementing CISA.
