# Smart-Contract Comparator

Reserved for a future comparative implementation.
