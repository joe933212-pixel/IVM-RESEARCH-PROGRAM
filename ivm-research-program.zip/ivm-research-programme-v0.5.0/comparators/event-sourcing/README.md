# Event-Sourcing Comparator

Reserved for a future comparative implementation.
