# Conventional State-Machine Comparator

Baseline comparator for Experiment 005.
