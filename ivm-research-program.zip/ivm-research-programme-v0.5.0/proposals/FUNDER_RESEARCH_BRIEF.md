# Institutional Virtual Machine Research Programme

## Research Funding Brief

### The proposition

The Institutional Virtual Machine research programme investigates whether institutional transitions can be represented as explicit computational semantics rather than being assembled implicitly across application logic, databases, workflows, identity systems and external institutional processes.

The programme is not asking a funder to accept that proposition as proven.

It is asking for support to determine it rigorously.

### Why this is research

The work has already moved beyond conceptual writing.

A reference runtime exists through v0.4. Controlled failure exposed a concrete State/History atomicity boundary. The architecture was modified in response. A dedicated process-death experiment then deliberately terminated the executing worker and recovered the durable transaction from a fresh process.

The historical process-death record reports 23 tests run and 23 passed under the defined conditions.

The research has now entered comparative execution. A conventional deterministic state-machine comparator has been constructed and tested against the same semantic contract.

The current result is deliberately treated as a challenge to the IVM proposition rather than as proof of it.

### What has been established

The current evidence supports the following limited conclusions.

The proposed institutional-transition model can be implemented as executable semantics.

Controlled failure can expose meaningful semantic boundaries in that implementation.

A local transactional representation can recover the tested transition after actual process termination.

A conventional state-machine implementation can satisfy the current Experiment 005 semantic contract.

These are useful results precisely because they narrow the unanswered questions.

### What remains unknown

The research has not established that IVM is novel.

It has not established that conventional systems cannot provide equivalent semantics.

It has not established production-grade durability, distributed atomicity, concurrency safety, replication, Byzantine tolerance or security under adversarial conditions.

The prior-art and literature analysis also requires completion and independent scrutiny.

### Proposed funded programme

The next research phase should focus on comparative execution, concurrency and duplicate recovery, persistence-boundary testing, formal semantic specification, independent replication, security analysis and independent technical review.

The objective is to determine whether the IVM abstraction survives increasingly strong attempts to reproduce or falsify its proposed properties using conventional approaches.

### Why funding is useful now

The programme has reached the point where further progress benefits materially from independent participation.

Funding would enable additional engineering capacity, independent replication, formal methods expertise, security review, comparative implementations, realistic storage and infrastructure testing, research documentation and external technical evaluation.

The request is therefore for research validation rather than for capital to commercialise an already-proven technology.

### Research philosophy

A funder should not have to trust the researcher merely because the researcher is confident.

The repository is designed so that the evidence can be inspected, the experiments can be rerun, the claims can be challenged and the hypothesis can fail.

If the research demonstrates that IVM is unnecessary because existing architectures already provide the required semantics, that will be a legitimate and valuable conclusion.

If the research demonstrates a persistent architectural gap, the resulting evidence will provide a stronger foundation for subsequent engineering, publication and commercialisation.

### Requested outcome

The desired outcome of the funded programme is not a predetermined product.

It is an independently reviewed answer to a precise architectural question:

**Does institutional execution require a distinct computational abstraction, or can its required semantics be provided naturally and reproducibly by existing execution models?**

The repository is the public research record through which that question can be investigated.
