# Funder Evaluation Guide

A reviewer entering the repository should be able to follow the research without relying on private conversations with the researcher.

## Start here

Read `README.md`.

Then read `docs/RESEARCH_EVIDENCE_CHAIN.md` and `docs/RESEARCH_CLAIMS_REGISTER.md`.

Then inspect the v0.3 fault-matrix findings and the v0.4 process-death experiment.

Then run the current reference-runtime tests.

Then inspect Experiment 005 and its conventional comparator.

Finally review the research roadmap and funding brief.

## What the reviewer should test

The central question is not whether the repository contains impressive terminology.

The reviewer should ask whether the experiments are reproducible, whether the semantic contract is clear, whether the comparator is fair, whether the claims match the evidence and whether the remaining research questions are substantial enough to justify independent investigation.

## What would falsify the strongest interpretation

Evidence that conventional execution models already provide the complete semantic abstraction without an additional IVM-equivalent layer would materially weaken the case for IVM as a distinct architecture.

Evidence that the current recovery behaviour depends on undocumented assumptions would weaken the recovery claim.

Evidence that the semantic contract is merely a restatement of established prior art would reduce the novelty claim.

These are not risks to be hidden from a funder. They are the research questions the funding is intended to resolve.
