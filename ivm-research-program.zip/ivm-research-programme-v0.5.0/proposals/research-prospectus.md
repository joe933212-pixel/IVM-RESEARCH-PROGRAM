# Research Prospectus

The Institutional Virtual Machine research programme investigates executable institutional semantics.

The work has progressed through conceptual architecture, reference-runtime development, failure-oriented testing, actual process-death recovery and comparative execution.

The next phase requires independent validation, comparative implementations, formal specification, security analysis, reproducibility infrastructure and external technical review.

Funding would support research validation rather than a predetermined commercial outcome.

The project explicitly welcomes evidence that reduces or falsifies its novelty claims.
