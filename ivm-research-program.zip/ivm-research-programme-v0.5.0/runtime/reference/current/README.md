# IVM Reference Runtime v0.4

A minimal executable research prototype for the Institutional Virtual Machine (IVM) and Coordination Instruction Set Architecture (CISA).

## Canonical execution sequence

`RECEIVE_EVENT -> LOAD_STATE -> VERIFY_AUTHORITY -> EVALUATE_RULES -> EXECUTE_TRANSITION -> COMMIT_STATE -> RECORD_HISTORY -> COMPLETE_EXECUTION`

## Version 0.4 focus

v0.3 fault injection exposed an atomicity gap between `COMMIT_STATE` and `RECORD_HISTORY`: an interrupted execution could leave a committed State transition without corresponding History.

v0.4 introduces a durable, JSON-backed transactional commitment journal for research purposes. A transaction progresses through:

`PREPARED -> STATE_COMMITTED -> HISTORY_ATTACHED -> FINALIZED`

Recovery resumes from the persisted transaction record and does not recalculate a new candidate State.

## Run

Python 3.10+

```bash
python -m unittest discover -s tests -v
python examples/run_license_demo.py
```

## Research status

This is **not production infrastructure**. The journal is intentionally small and single-process. It does not claim distributed consensus, database-grade durability, concurrency control or cryptographic notarization.

The purpose of v0.4 is to test the semantic proposition that institutional State commitment and its corresponding History can be represented as a single recoverable transaction rather than as unrelated operations.

See `TRANSACTIONAL_COMMIT_v0.4.md` for the research note and `TEST_RESULTS_v0.4.txt` for the complete test run.
