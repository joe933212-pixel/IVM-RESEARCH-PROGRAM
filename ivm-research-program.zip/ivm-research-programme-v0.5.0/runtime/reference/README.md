# IVM Reference Runtime

The `versions/` directory preserves the runtime snapshots produced during the experimental sequence.

`v0.1` is the initial reference runtime.

`v0.2` introduces fault injection.

`v0.3` introduces the canonical fault matrix and associated findings.

`v0.4` introduces transactional commit/recovery and the actual process-death experiment.

`current/` is a copy of the validated v0.4 snapshot used for repository verification. Historical versions are not overwritten.
