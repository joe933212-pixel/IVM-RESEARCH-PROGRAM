# Runtime Source Artifacts

Actual runtime ZIP archives supplied/generated during the IVM research workflow, preserved unchanged. Extracted copies are provided under `runtime/reference/versions/` for direct inspection.
