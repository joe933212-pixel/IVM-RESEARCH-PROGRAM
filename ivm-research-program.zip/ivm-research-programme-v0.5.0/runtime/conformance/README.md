# Conformance Model

Implementation-independent semantic requirements belong here.
