# Repository Verification

These results are packaging-time verification runs performed while assembling repository v0.2.0. They are not substituted for historical experiment records.

| Runtime / harness | Result |
|---|---|
| Reference Runtime v0.1 | 5 tests passed |
| Reference Runtime v0.2 | 9 tests passed |
| Reference Runtime v0.3 | 15 tests passed, 26 subtests passed |
| Reference Runtime v0.4 | 23 tests passed, 26 subtests passed |
| Experiment 005 conformance harness | 5 tests passed |

The v0.4 historical process-death experiment separately records 23 tests run and 23 passed after deliberate termination of a separate worker process and successful recovery by a fresh process.
