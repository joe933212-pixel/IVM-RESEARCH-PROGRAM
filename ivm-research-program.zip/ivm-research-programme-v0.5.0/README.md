# Institutional Virtual Machine Research Programme

## Executable institutional semantics for trusted digital infrastructure

The Institutional Virtual Machine (IVM) is a research programme investigating whether institutional rules, authority, state transitions, commitments and historical obligations can be represented as explicit computational semantics rather than being distributed implicitly across application logic, databases, workflow engines, identity systems and external institutional processes.

The central research question is:

> Can institutional transitions be represented as first-class computational objects in a way that is deterministic, recoverable, replayable, auditable and semantically faithful to the authority and rules governing the transition?

This repository is both a software repository and a research record. It preserves runtime versions, experiments, test outputs, specifications and research methodology.

## For researchers and funders

If you are evaluating the programme for research collaboration or funding, begin with:

`docs/RESEARCH_EVIDENCE_CHAIN.md`

`docs/RESEARCH_CLAIMS_REGISTER.md`

`proposals/FUNDER_RESEARCH_BRIEF.md`

`proposals/FUNDER_EVALUATION_GUIDE.md`

`docs/RESEARCH_ROADMAP.md`

These documents are designed to make the evidence, limitations, unanswered questions and proposed next-stage programme visible without requiring private context.

## Evidence currently in the repository

The reference runtime is preserved through v0.4. The v0.4 package includes transactional commit/recovery and actual process-death testing. The historical process-death result records 23 tests run and 23 passed, with recovery by a fresh process after deliberate termination at defined transaction boundaries.

The repository also contains a conformance harness for Experiment 005. Its canonical scenario begins with a business-licence transition from PENDING to ACTIVE and tests duplicate events, authority revocation, rule-version history and semantic difference detection.

The repository's packaging verification reproduced passing runtime and conformance tests. These are new verification runs and are not presented as historical experimental records.

## Research posture

The project explicitly welcomes criticism, replication, prior-art identification, competing implementations and falsification.

The repository does not claim that IVM is a new computer architecture, that conventional systems cannot represent the proposed semantics, that the model is commercially superior, or that patentability is established.

If existing technology already provides a proposed property, identifying that fact is a useful research result.

If an experiment fails, the failure should remain part of the research record.

## Repository map

`docs/` contains the research question, hypothesis, methodology, archive index, chronology, evidence chain, claims register and roadmap.

`specifications/` contains the CRS, CISA, CEE and currently available IVM source documents.

`runtime/reference/versions/` preserves the historical executable runtime snapshots.

`experiments/` contains experiment definitions and the Experiment 005 conformance harness.

`results/` contains historical and repository-verification results.

`literature/` contains the prior-art analysis status and its continuation point.

`proposals/` contains research-funding material and the recommended reviewer path.

## Current research boundary

The project has progressed from conceptual architecture to executable runtime research, failure injection, actual process-death recovery and comparative execution.

The next research stage is independent comparative validation rather than assuming architectural novelty.

## Principal researcher

Joel Kagoro

Uganda

Research focus: institutional computing, trusted infrastructure, digital public infrastructure and execution systems.

## Actual source artifacts

This release preserves the actual runtime and Experiment 005 archives supplied during the research workflow, alongside extracted copies for direct inspection. Original source documents are preserved unchanged where available.
