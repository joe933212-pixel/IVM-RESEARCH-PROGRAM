# Source Literature Artifacts

Original supplied source documents are preserved unchanged in this directory.
