# Experiment 002

Original protocol and results to be imported from the verified research artefacts.
