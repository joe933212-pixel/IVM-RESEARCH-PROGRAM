# Process-Death Recovery

Research question: Can recovery survive actual process death?

The original protocol and evidence should be imported from the verified research artefacts.
