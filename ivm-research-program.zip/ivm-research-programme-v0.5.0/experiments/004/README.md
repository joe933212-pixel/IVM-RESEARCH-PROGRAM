# Experiment 004

Failure-oriented experiment. Original protocol and results to be imported from the verified research artefacts.
