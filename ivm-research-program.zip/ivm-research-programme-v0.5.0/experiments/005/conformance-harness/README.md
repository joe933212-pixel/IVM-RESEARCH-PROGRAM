# IVM Experiment 005 — Conformance Harness

First executable laboratory for Experiment 005.

The package defines a canonical institutional transition and a common semantic result
vector, then implements the first comparator: a conventional deterministic state machine.

This is not an IVM implementation. It is the baseline against which the IVM reference
runtime will later be compared.

Passing this package does not prove IVM novelty. It demonstrates that the first
conventional comparator satisfies the canonical semantic contract.
