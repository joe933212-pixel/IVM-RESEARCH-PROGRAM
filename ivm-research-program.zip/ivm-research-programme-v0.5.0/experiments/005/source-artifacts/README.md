# Experiment 005 Source Artifact

The original Experiment 005 conformance-harness ZIP is preserved unchanged here. An extracted copy is available under `experiments/005/source/`.
