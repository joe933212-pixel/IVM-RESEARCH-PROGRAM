# Experiment 005 — Process-Death Comparator

The comparator must be tested under an equivalent process-death condition for methodological fairness.
