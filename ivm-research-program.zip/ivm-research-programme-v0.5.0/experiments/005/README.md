# Experiment 005 — Comparative Institutional Execution

Experiment 005 begins the comparative execution programme.

The packaged conformance harness contains the canonical transition and a conventional deterministic state-machine comparator.

The canonical transition is:

`PENDING -> ACTIVE`

The harness currently tests canonical transition execution, duplicate-event handling, authority revocation, rule-version history preservation and detection of semantic differences.

The repository verification run produced 5 passing tests.

This harness is evidence of a comparative methodology, not evidence that IVM has already been shown superior or novel.
